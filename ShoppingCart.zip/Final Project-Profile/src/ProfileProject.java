
public class ProfileProject {
	import java.util.Scanner;
	public class FinalProject {

	public static void main(String[] args) {
	// TODO Auto-generated method stub

	Scanner sc = new Scanner (System.in);
	System.out.println("Please input your name: ");
	String username = sc.nextLine();
	username = username.toUpperCase();

	System.out.println("What's your name?");
	System.out.println("Address") ;
	System.out.println("\nInput your phone number in (xxx-xxx-xxxx) format: ");
	System.out.println("\nInput your email address: ");
	System.out.println("\nTell us a little about yourself: ");
	System.out.println("Thank you. We have your personal information.");

}
